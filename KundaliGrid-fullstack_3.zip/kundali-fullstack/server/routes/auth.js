// server/routes/auth.js
// ════════════════════════════════════════════════════════════════════════════
// AUTH — owner identity by email. Only the owner (you) has an account;
// everyone else uses the site as an anonymous visitor (no login needed).
// ════════════════════════════════════════════════════════════════════════════

const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { db } = require('../db');

const router = express.Router();
const JWT_SECRET = process.env.JWT_SECRET || 'change-this-secret-in-production';
const JWT_EXPIRY = '90d'; // long-lived so your PC stays logged in

// ── SIGNUP (one-time, for you the owner) ──────────────────────────────────────
router.post('/signup', async (req, res) => {
  try {
    const { email, password, name } = req.body;
    if (!email || !password) return res.status(400).json({ error: 'Email and password required' });

    await db.read();
    const existing = db.data.owners.find(o => o.email.toLowerCase() === email.toLowerCase());
    if (existing) return res.status(409).json({ error: 'An account with this email already exists' });

    // First-ever signup becomes the sole owner. Optionally limit to ONE owner account total.
    if (db.data.owners.length >= 1) {
      return res.status(403).json({ error: 'Owner account already exists. Only one owner is allowed for this site.' });
    }

    const passwordHash = await bcrypt.hash(password, 10);
    const owner = {
      id: 'owner_' + Date.now(),
      email: email.toLowerCase(),
      passwordHash,
      name: name || '',
      createdAt: new Date().toISOString(),
    };
    db.data.owners.push(owner);
    await db.write();

    const token = jwt.sign({ ownerId: owner.id, email: owner.email }, JWT_SECRET, { expiresIn: JWT_EXPIRY });
    res.json({ token, owner: { id: owner.id, email: owner.email, name: owner.name } });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error during signup' });
  }
});

// ── LOGIN ──────────────────────────────────────────────────────────────────────
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    await db.read();
    const owner = db.data.owners.find(o => o.email.toLowerCase() === (email || '').toLowerCase());
    if (!owner) return res.status(401).json({ error: 'Invalid email or password' });

    const valid = await bcrypt.compare(password, owner.passwordHash);
    if (!valid) return res.status(401).json({ error: 'Invalid email or password' });

    const token = jwt.sign({ ownerId: owner.id, email: owner.email }, JWT_SECRET, { expiresIn: JWT_EXPIRY });
    res.json({ token, owner: { id: owner.id, email: owner.email, name: owner.name } });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error during login' });
  }
});

// ── CHANGE EMAIL/PASSWORD (owner recovery / device change) ────────────────────
router.post('/update-credentials', requireAuth, async (req, res) => {
  try {
    const { newEmail, newPassword, currentPassword } = req.body;
    await db.read();
    const owner = db.data.owners.find(o => o.id === req.ownerId);
    if (!owner) return res.status(404).json({ error: 'Owner not found' });

    const valid = await bcrypt.compare(currentPassword || '', owner.passwordHash);
    if (!valid) return res.status(401).json({ error: 'Current password incorrect' });

    if (newEmail) owner.email = newEmail.toLowerCase();
    if (newPassword) owner.passwordHash = await bcrypt.hash(newPassword, 10);
    await db.write();

    const token = jwt.sign({ ownerId: owner.id, email: owner.email }, JWT_SECRET, { expiresIn: JWT_EXPIRY });
    res.json({ token, owner: { id: owner.id, email: owner.email, name: owner.name } });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error updating credentials' });
  }
});

// ── MIDDLEWARE: verify owner JWT ──────────────────────────────────────────────
function requireAuth(req, res, next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) return res.status(401).json({ error: 'Not authenticated' });
  try {
    const payload = jwt.verify(token, JWT_SECRET);
    req.ownerId = payload.ownerId;
    req.ownerEmail = payload.email;
    next();
  } catch {
    return res.status(401).json({ error: 'Invalid or expired session' });
  }
}

router.get('/whoami', requireAuth, async (req, res) => {
  await db.read();
  const owner = db.data.owners.find(o => o.id === req.ownerId);
  if (!owner) return res.status(404).json({ error: 'Owner not found' });
  res.json({ owner: { id: owner.id, email: owner.email, name: owner.name } });
});

router.get('/owner-exists', async (req, res) => {
  await db.read();
  res.json({ exists: db.data.owners.length > 0 });
});

module.exports = { router, requireAuth };
