// server/routes/data.js
// ════════════════════════════════════════════════════════════════════════════
// OWNER DATA SYNC — persons/groups/matches, scoped to the logged-in owner.
// This is what backs up your local data when you're online.
// ════════════════════════════════════════════════════════════════════════════

const express = require('express');
const { db } = require('../db');
const { requireAuth } = require('./auth');

const router = express.Router();
router.use(requireAuth); // everything here requires owner login

// ── PERSONS ────────────────────────────────────────────────────────────────────
router.get('/persons', async (req, res) => {
  await db.read();
  const mine = db.data.persons.filter(p => p.ownerId === req.ownerId);
  res.json({ persons: mine });
});

// Full sync: replace all of the owner's persons with what the client sends.
// Used when the device comes back online after working offline.
router.post('/persons/sync', async (req, res) => {
  const { persons } = req.body;
  if (!Array.isArray(persons)) return res.status(400).json({ error: 'persons must be an array' });
  await db.read();
  db.data.persons = db.data.persons.filter(p => p.ownerId !== req.ownerId);
  persons.forEach(p => db.data.persons.push({ ...p, ownerId: req.ownerId }));
  await db.write();
  res.json({ ok: true, count: persons.length });
});

router.post('/persons', async (req, res) => {
  await db.read();
  const person = { ...req.body, ownerId: req.ownerId, id: req.body.id || ('p_' + Date.now() + '_' + Math.random().toString(36).slice(2,6)) };
  db.data.persons.push(person);
  await db.write();
  res.json({ person });
});

router.put('/persons/:id', async (req, res) => {
  await db.read();
  const idx = db.data.persons.findIndex(p => p.id === req.params.id && p.ownerId === req.ownerId);
  if (idx === -1) return res.status(404).json({ error: 'Not found' });
  db.data.persons[idx] = { ...db.data.persons[idx], ...req.body, ownerId: req.ownerId };
  await db.write();
  res.json({ person: db.data.persons[idx] });
});

router.delete('/persons/:id', async (req, res) => {
  await db.read();
  db.data.persons = db.data.persons.filter(p => !(p.id === req.params.id && p.ownerId === req.ownerId));
  await db.write();
  res.json({ ok: true });
});

router.post('/persons/bulk-delete', async (req, res) => {
  const { ids } = req.body;
  await db.read();
  const idSet = new Set(ids || []);
  db.data.persons = db.data.persons.filter(p => !(idSet.has(p.id) && p.ownerId === req.ownerId));
  await db.write();
  res.json({ ok: true });
});

// ── GROUPS ─────────────────────────────────────────────────────────────────────
router.get('/groups', async (req, res) => {
  await db.read();
  res.json({ groups: db.data.groups.filter(g => g.ownerId === req.ownerId) });
});
router.post('/groups', async (req, res) => {
  await db.read();
  const group = { ...req.body, ownerId: req.ownerId, id: req.body.id || ('g_' + Date.now()) };
  db.data.groups.push(group);
  await db.write();
  res.json({ group });
});
router.delete('/groups/:id', async (req, res) => {
  await db.read();
  db.data.groups = db.data.groups.filter(g => !(g.id === req.params.id && g.ownerId === req.ownerId));
  await db.write();
  res.json({ ok: true });
});

// ── MATCHES / PREDICTIONS ───────────────────────────────────────────────────────
router.get('/matches', async (req, res) => {
  await db.read();
  res.json({ matches: db.data.matches.filter(m => m.ownerId === req.ownerId) });
});
router.post('/matches', async (req, res) => {
  await db.read();
  const match = { ...req.body, ownerId: req.ownerId, id: req.body.id || ('m_' + Date.now()) };
  db.data.matches.push(match);
  await db.write();
  res.json({ match });
});
router.delete('/matches/:id', async (req, res) => {
  await db.read();
  db.data.matches = db.data.matches.filter(m => !(m.id === req.params.id && m.ownerId === req.ownerId));
  await db.write();
  res.json({ ok: true });
});

// ── VISITOR LOG (owner views who's been on the site) ───────────────────────────
router.get('/visitors', async (req, res) => {
  await db.read();
  const sorted = [...db.data.visitors].sort((a, b) => new Date(b.at) - new Date(a.at));
  res.json({ visitors: sorted });
});

// ── BOOKING REQUESTS (owner views call/session requests) ───────────────────────
router.get('/booking-requests', async (req, res) => {
  await db.read();
  const sorted = [...db.data.bookingRequests].sort((a, b) => new Date(b.at) - new Date(a.at));
  res.json({ requests: sorted });
});
router.put('/booking-requests/:id', async (req, res) => {
  await db.read();
  const idx = db.data.bookingRequests.findIndex(r => r.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'Not found' });
  db.data.bookingRequests[idx] = { ...db.data.bookingRequests[idx], ...req.body };
  await db.write();
  res.json({ request: db.data.bookingRequests[idx] });
});

module.exports = router;
